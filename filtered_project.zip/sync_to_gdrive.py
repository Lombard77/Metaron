# File: sync_to_gdrive.py

import os
import shutil
import time
from datetime import datetime

SOURCE_DIR = r"C:\MyDevProjects\Metatron"
DEST_DIR = r"G:\My Drive\Personal\My Dev Projects\MetatronBackupFromC"
LOG_FILE = os.path.join(SOURCE_DIR, "last_sync.log")

def should_copy(src_path, dest_path):
    return (
        not os.path.exists(dest_path)
        or os.path.getmtime(src_path) > os.path.getmtime(dest_path)
    )

def sync_folder(src, dest):
    for root, dirs, files in os.walk(src):
        rel_path = os.path.relpath(root, src)
        dest_root = os.path.join(dest, rel_path)

        os.makedirs(dest_root, exist_ok=True)

        for f in files:
            src_file = os.path.join(root, f)
            dest_file = os.path.join(dest_root, f)

            try:
                if should_copy(src_file, dest_file):
                    shutil.copy2(src_file, dest_file)
            except Exception as e:
                with open(LOG_FILE, "a") as log:
                    log.write(f"[ERROR] {src_file} -> {dest_file}: {e}\n")

def main():
    start = datetime.now()
    with open(LOG_FILE, "a") as log:
        log.write(f"\n=== Sync started: {start.isoformat()} ===\n")
    sync_folder(SOURCE_DIR, DEST_DIR)
    end = datetime.now()
    duration = (end - start).total_seconds()
    with open(LOG_FILE, "a") as log:
        log.write(f"✔️ Sync completed at {end.isoformat()} (Duration: {duration:.2f} sec)\n")

if __name__ == "__main__":
    main()
