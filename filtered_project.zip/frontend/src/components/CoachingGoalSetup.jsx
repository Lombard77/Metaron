import { useState, useEffect } from "react";
import axios from "axios";

export default function CoachingGoalSetup({ onGoalCreated, onCancel, goal = null }) {
  const [goalName, setGoalName] = useState(goal?.title || "");
  const [intent, setIntent] = useState(goal?.intent || "Study");
  const [timeframe, setTimeframe] = useState(goal?.timeframe || "14 days");
  const [description, setDescription] = useState(goal?.description || "");
  const [provider, setProvider] = useState(goal?.provider || "Open Source");
  const [apiKey, setApiKey] = useState("");
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState("");
  const [buttonLabel, setButtonLabel] = useState("🚀 Create Coaching Goal");
  const [jobId, setJobId] = useState(null);

  const [originalState] = useState({
    title: goal?.title || "",
    intent: goal?.intent || "Study",
    timeframe: goal?.timeframe || "14 days",
    description: goal?.description || "",
    provider: goal?.provider || "Open Source"
  });

  const isUnchanged =
    goal &&
    goalName === originalState.title &&
    intent === originalState.intent &&
    timeframe === originalState.timeframe &&
    description === originalState.description &&
    provider === originalState.provider &&
    files.length === 0;

  const handleFileChange = (e) => setFiles(Array.from(e.target.files));

  useEffect(() => {
    let intervalId;
    if (loading && jobId) {
      const cycle = [
        { status: "📦 Uploading files...", button: "Uploading..." },
        { status: "🧠 Embedding content...", button: "Embedding..." },
        { status: "📊 Finalizing...", button: "Finalizing..." }
      ];
      let i = 0;

      intervalId = setInterval(async () => {
        try {
          const res = await axios.get(`http://localhost:8000/job-status?job_id=${jobId}`);
          if (res.data.status === "complete") {
            setStatusMessage("✅ Embedding complete!");
            setButtonLabel("✅ Goal Created!");
            setLoading(false);
            clearInterval(intervalId);
          } else {
            const { status, button } = cycle[i];
            setStatusMessage(`🔄 ${res.data.status || status}`);
            setButtonLabel(button);
            i = (i + 1) % cycle.length;
          }
        } catch (err) {
          console.error("Polling error:", err);
          setStatusMessage("❌ Failed to fetch status. Check logs.");
          setButtonLabel("❌ Error");
          setLoading(false);
          clearInterval(intervalId);
        }
      }, 3000);
    }
    return () => clearInterval(intervalId);
  }, [loading, jobId]);

  const handleCreateGoal = async () => {
    const userId = localStorage.getItem("user_id");
    if (!userId) {
      setStatusMessage("❌ You are not logged in. Please log in first.");
      return;
    }

    if (!goalName || (!goal && files.length === 0)) {
      setStatusMessage("❌ Please provide a goal name and at least one file.");
      return;
    }

    const formData = new FormData();
    formData.append("user_id", userId);
    formData.append("goal_name", goalName);
    formData.append("intent", intent);
    formData.append("timeframe", timeframe);
    formData.append("description", description);
    formData.append("provider", provider);
    if (provider === "OpenAI") formData.append("api_key", apiKey);
    files.forEach((file) => formData.append("files", file));

    setLoading(true);
    setStatusMessage("🔄 Uploading and embedding in progress...");
    setButtonLabel("Creating...");

    try {
      const res = await axios.post("http://localhost:8000/upload-kb", formData);
      if (res.data.job_id) {
        setJobId(res.data.job_id);
      } else {
        setStatusMessage("✅ Coaching Goal created (no job tracking).");
        setButtonLabel("✅ Created!");
        setLoading(false);
      }

      if (onGoalCreated) {
        onGoalCreated({
          id: Date.now(),
          title: goalName,
          intent,
          timeframe,
          description,
          provider
        });
      }
    } catch (err) {
      setStatusMessage("❌ Upload failed. Please try a smaller or simpler file.");
      setButtonLabel("❌ Failed");
      console.error("Upload error:", err);
      setLoading(false);
    }
  };

  const handleAbort = () => {
    const confirmed = window.confirm("Are you sure you want to abort and discard all changes?");
    if (confirmed) {
      console.warn("🛑 User aborted coaching goal creation/editing.");
      if (onCancel) onCancel();
    }
  };

  return (
    <div className="max-w-xl mx-auto p-6 bg-white rounded-lg shadow-md">
      <h2 className="text-xl font-bold mb-4">
        {goal ? "Edit Coaching Goal" : "Create a Coaching Goal"}
      </h2>

      <label className="block mb-2">Goal Name</label>
      <input
        type="text"
        value={goalName}
        onChange={(e) => setGoalName(e.target.value)}
        className="w-full mb-4 p-2 border rounded"
        disabled={loading}
      />

      <label className="block mb-2">Select AI Engine</label>
      <select
        value={provider}
        onChange={(e) => setProvider(e.target.value)}
        className="w-full mb-2 p-2 border rounded"
        disabled={loading}
      >
        <option value="Open Source">Open Source (Free, slower)</option>
        <option value="OpenAI">OpenAI (Faster, requires API key)</option>
      </select>

      {provider === "OpenAI" && (
        <div className="mb-4">
          <p className="text-sm text-gray-600 mb-1">OpenAI usage may incur additional costs. Enter your API key below:</p>
          <input
            type="password"
            value={apiKey}
            onChange={(e) => setApiKey(e.target.value)}
            className="w-full p-2 border rounded"
            disabled={loading}
          />
        </div>
      )}

      <label className="block mb-2">Upload Files</label>
      <input
        type="file"
        multiple
        onChange={handleFileChange}
        className="hidden"
        id="file-upload"
        disabled={loading}
      />
      <label htmlFor="file-upload" className="inline-block mb-2 px-4 py-2 bg-blue-100 text-blue-700 rounded cursor-pointer hover:bg-blue-200">
        📁 Choose Files
      </label>
      {files.map((file) => (
        <div key={file.name} className="text-xs text-gray-600 ml-1 mb-1">
          {file.name} — {(file.size / (1024 * 1024)).toFixed(2)} MB
        </div>
      ))}

      <label className="block mb-2">Intent</label>
      <select
        value={intent}
        onChange={(e) => setIntent(e.target.value)}
        className="w-full mb-4 p-2 border rounded"
        disabled={loading}
      >
        <option>Study</option>
        <option>Test</option>
        <option>Assignment</option>
      </select>

      <label className="block mb-2">Timeframe</label>
      <select
        value={timeframe}
        onChange={(e) => setTimeframe(e.target.value)}
        className="w-full mb-4 p-2 border rounded"
        disabled={loading}
      >
        <option>7 days</option>
        <option>14 days</option>
        <option>30 days</option>
        <option>Custom</option>
      </select>

      <label className="block mb-2">Goal Description</label>
      <textarea
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        className="w-full mb-4 p-2 border rounded"
        rows={3}
        disabled={loading}
      ></textarea>

      {statusMessage && (
        <div className="text-sm text-center text-gray-600 mb-2 whitespace-pre-line">
          {statusMessage}
        </div>
      )}

      <div className="flex gap-2">
        <button
          onClick={() => {
            if (isUnchanged) {
              setStatusMessage("⚠️ No changes detected.");
              return;
            }
            if (goal && !window.confirm("Saving changes will overwrite your previous plan and reset progress. Continue?")) {
              return;
            }
            handleCreateGoal();
          }}
          disabled={loading}
          className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
        >
          {loading ? buttonLabel : goal ? "💾 Save Changes" : "🚀 Create Coaching Goal"}
        </button>

        <button
          onClick={handleAbort}
          disabled={loading && !jobId}
          className="w-32 bg-gray-300 text-gray-800 py-2 rounded hover:bg-gray-400"
        >
          ✖ Cancel
        </button>
      </div>
    </div>
  );
}
