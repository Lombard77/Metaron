import { useState, useEffect } from "react";
import { Menu } from "lucide-react";
import CoachingGoalSetup from "./CoachingGoalSetup";

export default function Dashboard() {
  const [goals, setGoals] = useState([]); // Replaces plans
  const [selectedGoal, setSelectedGoal] = useState(null);
  const [mode, setMode] = useState("home"); // Modes: home, create, edit, chat
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const handleLogout = () => {
    localStorage.clear();
    window.location.reload();
  };

  useEffect(() => {
    setGoals([]); // Replace with real fetch from API later
  }, []);

  const handleCreateNewGoal = () => {
    setMode("create");
    setSelectedGoal(null);
  };

  const handleSelectGoal = (goal) => {
    setSelectedGoal(goal);
    setMode("preview");
  };

  const handleGoalCreated = (goal) => {
    setGoals((prev) => [...prev, goal]);
    setSelectedGoal(goal);
    setMode("preview");
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Sidebar */}
      {sidebarOpen ? (
        <div className="w-64 bg-white border-r border-gray-200 p-4 text-sm relative">
          {/* Collapse button */}
          <button
            className="absolute top-4 right-4 text-gray-500 hover:text-blue-500 transition"
            onClick={() => setSidebarOpen(false)}
            title="Collapse"
          >
            ✕
          </button>

          {/* Logo (left-aligned) */}
          <div className="mb-6 pl-1">
            <img src="/logo.png" alt="Metatron Logo" className="w-16" />
          </div>

          {/* Plan List */}
          <h3 className="font-semibold text-gray-600 mb-2 uppercase text-xs">Your Coaching Goals</h3>
          <ul className="space-y-2">
            {goals.map((goal) => (
              <li
                key={goal.id}
                onClick={() => handleSelectGoal(goal)}
                className={`cursor-pointer px-3 py-2 rounded-lg transition hover:bg-blue-100 ${
                  selectedGoal?.id === goal.id ? "bg-blue-200 font-semibold" : ""
                }`}
              >
                {goal.title}
              </li>
            ))}
          </ul>

          {/* Add Coaching Goal */}
          <button
            onClick={handleCreateNewGoal}
            className="mt-6 w-full py-2 px-4 bg-blue-600 text-white rounded-full hover:bg-blue-700 text-sm"
          >
            New Coaching Goal
          </button>

          {/* Footer */}
          <div className="mt-8 text-xs text-gray-400 text-center">Metatron • View plans</div>
        </div>
      ) : (
        <div className="w-10 bg-transparent p-2">
          <button
            className="text-gray-500 hover:text-blue-500"
            onClick={() => setSidebarOpen(true)}
            title="Open Menu"
          >
            <Menu size={24} />
          </button>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 overflow-y-auto">
        {/* Top Header with Logo + Text */}
        <div className="flex justify-between items-center gap-4 p-6 border-b border-gray-200 bg-white">
          {/* Left: Title and Slogan */}
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Metatron</h1>
            <p className="text-sm text-gray-500">A Guiding Light in the Ocean of Knowledge</p>
          </div>

          {/* Right: Profile Dropdown */}
          <div className="relative">
            <button
              className="text-sm font-medium text-gray-700 bg-gray-100 rounded-full px-3 py-1 hover:bg-gray-200"
              onClick={() => setShowProfileMenu(!showProfileMenu)}
            >
              👤 Profile
            </button>
            {showProfileMenu && (
              <div className="absolute right-0 mt-2 w-40 bg-white border rounded-md shadow-md z-10">
                <button
                  className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100"
                  onClick={handleLogout}
                >
                  Log Out
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Main Panel */}
        <div className="p-10">
          {mode === "home" && (
            <div className="text-gray-500 text-lg mt-10">
              Please select or create a coaching goal to begin.
            </div>
          )}

          {mode === "create" && (
            <CoachingGoalSetup onGoalCreated={handleGoalCreated} />
          )}

          {mode === "preview" && selectedGoal && (
            <div>
              <h2 className="text-xl font-semibold mb-4">{selectedGoal.title}</h2>
              <p className="text-gray-700 mb-4">{selectedGoal.description || "No description provided."}</p>
              <div className="flex gap-4">
                <button
                  onClick={() => setMode("edit")}
                  className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600"
                >
                  Edit Goal
                </button>
                <button
                  onClick={() => setMode("chat")}
                  className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
                >
                  Start Session
                </button>
              </div>
            </div>
          )}

          {mode === "edit" && selectedGoal && (
            <CoachingGoalSetup goal={selectedGoal} onGoalCreated={handleGoalCreated} />
          )}
        </div>
      </div>
    </div>
  );
}
