✅ CONFIRMED: Your Actual Stack
You're using:

Frontend: Vite + React + Tailwind CSS

Backend: Python FastAPI, not Node or Flask

Backend run command: uvicorn main:app --reload

Frontend run command: npm run dev

No npm used in backend, because it's not Node-based

You were also working inside a venv Python virtual environment.

