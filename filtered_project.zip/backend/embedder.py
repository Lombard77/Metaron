# File: backend/embedder.py

import os
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import Chroma
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from dotenv import load_dotenv
from logger import log_error  # ✅ NEW

load_dotenv()  # Ensures .env is loaded if this file is run/imported

# Directory where your vector database files will be stored
chroma_dir = "data/vector_store"

# This uses OpenAI's & HuggingFace embedding models      
def get_embedding_function(provider, api_key):
    if provider == "OpenAI (Additional AI Costs)":
        return OpenAIEmbeddings(openai_api_key=api_key)
    else:
        return HuggingFaceEmbeddings(model_name="BAAI/bge-small-en")

# -----------------------------------------
# Function: embed_and_store
# -----------------------------------------
def embed_and_store(text, namespace, provider, api_key):
    """
    Takes raw text and:
    - Splits it into smaller chunks
    - Embeds those chunks using OpenAI or HuggingFace
    - Stores them in a Chroma vector DB using the provided namespace

    Parameters:
    - text: full cleaned text to index
    - namespace: unique session ID or user ID (keeps each tutor’s data isolated)
    """
    try:
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
        docs = text_splitter.create_documents([text])

        try:
            embedding_function = get_embedding_function(provider, api_key)
        except Exception as embed_err:
            log_error("embedding-init", str(embed_err))
            raise RuntimeError("❌ Could not initialize embedding function.")


        db = Chroma(
            collection_name=namespace,
            persist_directory=chroma_dir,
            embedding_function=embedding_function,
        )

        db.add_documents(docs)
        db.persist()
    except Exception as e:
        log_error("embed_and_store", str(e))
        raise RuntimeError("⚠️ Embedding failed. Check logs for details.")

# -----------------------------------------
# Function: load_vectorstore
# -----------------------------------------
def load_vectorstore(namespace, provider, api_key):
    """
    Loads the stored vector database (for retrieval during chat).
    Parameters:
    - namespace: session ID or user ID (same as used in embed_and_store)
    Returns:
    - A Chroma vector store ready for semantic search
    """
    embedding_function = get_embedding_function(provider, api_key)

    return Chroma(
        collection_name=namespace,
        persist_directory=chroma_dir,
        embedding_function=embedding_function,
    )

def build_engine():
    from langchain_community.embeddings import HuggingFaceEmbeddings
    from langchain_community.vectorstores import Chroma

    embedding_function = HuggingFaceEmbeddings(model_name="BAAI/bge-small-en")
    return Chroma(
        persist_directory="data/vector_store",
        embedding_function=embedding_function
    )
