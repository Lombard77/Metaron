# File: backend/logger.py

import sqlite3
from datetime import datetime
import os
from uuid import uuid4
import hashlib

# Create logs directory if not exist
log_dir = "logs"
os.makedirs(log_dir, exist_ok=True)
log_path = os.path.join(log_dir, "chat_logs.db")

# Init DB
conn = sqlite3.connect(log_path)
c = conn.cursor()

# Table: users
c.execute('''
    CREATE TABLE IF NOT EXISTS users (
        email TEXT PRIMARY KEY,
        password_hash TEXT,
        first_name TEXT,
        last_name TEXT,
        age_group TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
''')

# Table: chat logs
c.execute('''
    CREATE TABLE IF NOT EXISTS logs (
        timestamp TEXT,
        session_id TEXT,
        question TEXT,
        response TEXT
    )
''')

# Table: uploads
c.execute('''
    CREATE TABLE IF NOT EXISTS uploads (
        timestamp TEXT,
        session_id TEXT,
        filename TEXT
    )
''')

# Table: coaching goals metadata
c.execute('''
    CREATE TABLE IF NOT EXISTS kb_meta (
        id TEXT PRIMARY KEY,
        organization_id TEXT,
        team_leader_id TEXT,
        user_id TEXT,
        kb_name TEXT,
        intent TEXT,
        timeframe_type TEXT,
        timeframe_value TEXT,
        goal_description TEXT,
        created_at TEXT,
        last_accessed_at TEXT
    )
''')

conn.commit()
conn.close()

# -------------------- USERS --------------------

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def create_user(email, password, first_name, last_name, age_group):
    conn = sqlite3.connect(log_path)
    c = conn.cursor()
    c.execute('''
        INSERT INTO users (email, password_hash, first_name, last_name, age_group)
        VALUES (?, ?, ?, ?, ?)
    ''', (email, hash_password(password), first_name, last_name, age_group))
    conn.commit()
    conn.close()

def user_exists(email):
    conn = sqlite3.connect(log_path)
    c = conn.cursor()
    c.execute("SELECT 1 FROM users WHERE email = ?", (email,))
    result = c.fetchone()
    conn.close()
    return result is not None

def validate_login(email, password):
    conn = sqlite3.connect(log_path)
    c = conn.cursor()
    c.execute("SELECT password_hash FROM users WHERE email = ?", (email,))
    row = c.fetchone()
    conn.close()
    return row and row[0] == hash_password(password)

def get_user_profile(email):
    conn = sqlite3.connect(log_path)
    c = conn.cursor()
    c.execute("SELECT email, first_name, last_name, age_group FROM users WHERE email = ?", (email,))
    row = c.fetchone()
    conn.close()
    if row:
        return {
            "email": row[0],
            "first_name": row[1],
            "last_name": row[2],
            "age_group": row[3],
        }
    return None

# -------------------- LOGGING --------------------

def log_chat(session_id, question, response):
    timestamp = datetime.utcnow().isoformat()
    conn = sqlite3.connect(log_path)
    c = conn.cursor()
    c.execute(
        "INSERT INTO logs VALUES (?, ?, ?, ?)",
        (timestamp, session_id, question, response)
    )
    conn.commit()
    conn.close()

def log_uploaded_files(session_id, filenames):
    timestamp = datetime.utcnow().isoformat()
    conn = sqlite3.connect(log_path)
    c = conn.cursor()
    for fname in filenames:
        c.execute(
            "INSERT INTO uploads VALUES (?, ?, ?)",
            (timestamp, session_id, fname)
        )
    conn.commit()
    conn.close()

def save_kb_metadata(org_id, team_leader_id, user_id, kb_name, intent, timeframe_type, timeframe_value, goal_description):
    conn = sqlite3.connect(log_path)
    c = conn.cursor()
    record_id = str(uuid4())
    now = datetime.utcnow().isoformat()

    c.execute('''
        INSERT INTO kb_meta (
            id, organization_id, team_leader_id, user_id, kb_name,
            intent, timeframe_type, timeframe_value, goal_description,
            created_at, last_accessed_at
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        record_id, org_id, team_leader_id, user_id, kb_name,
        intent, timeframe_type, timeframe_value, goal_description,
        now, now
    ))

    conn.commit()
    conn.close()
    return record_id

def get_kb_metadata(user_id, kb_name):
    conn = sqlite3.connect(log_path)
    c = conn.cursor()
    c.execute('''
        SELECT intent, timeframe_type, timeframe_value, goal_description
        FROM kb_meta
        WHERE user_id = ? AND kb_name = ?
        ORDER BY last_accessed_at DESC
        LIMIT 1
    ''', (user_id, kb_name))
    row = c.fetchone()
    conn.close()
    if row:
        return {
            'intent': row[0],
            'timeframe_type': row[1],
            'timeframe_value': row[2],
            'goal_description': row[3]
        }
    return None

# -------------------- ERROR LOGGING --------------------

def log_error(context, error_msg):
    """
    Appends an error message to logs/error.log with timestamp and context.
    """
    os.makedirs("logs", exist_ok=True)
    with open("logs/error.log", "a", encoding="utf-8") as f:
        f.write(f"[{datetime.utcnow().isoformat()}] [{context}] {error_msg}\n")

